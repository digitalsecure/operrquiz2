package com.example.operrquiz2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import com.example.operrquiz2.BuildConfig

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_main)

        val currentBuild = BuildConfig.BUILD_TYPE;
        val textView = findViewById<TextView>(R.id.buildstatusText);
        textView.setText(currentBuild);

    }
}
